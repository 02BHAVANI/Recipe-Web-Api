﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace RecipeAPI.Domain.Entities
{
    public class BaseEntity
    {
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }

    [Table("Category")]
    public class Category : BaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Recipe> Recipes { get; set; }
    }

    [Table("Ingredient")]
    public class Ingredient : BaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    [Table("Recipe")]
    public class Recipe : BaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
        public string IngredientJson { get; set; }
        public string Instructions { get; set; }
    }
}