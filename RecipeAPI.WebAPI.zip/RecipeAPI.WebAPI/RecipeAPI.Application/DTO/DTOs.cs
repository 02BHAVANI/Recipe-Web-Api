﻿namespace RecipeAPI.Application.DTOs
{
    public class CategoryDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class IngredientDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class RecipeDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CategoryId { get; set; }
        public string IngredientJson { get; set; }
        public string Instructions { get; set; }
    }
}