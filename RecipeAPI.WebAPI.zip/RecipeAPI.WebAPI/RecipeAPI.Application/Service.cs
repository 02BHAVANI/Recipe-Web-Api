﻿using RecipeAPI.Application.DTOs;
using RecipeAPI.Domain.Entities;
using RecipeAPI.Domain.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RecipeAPI.Application.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryService(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        public async Task<List<CategoryDTO>> GetAllCategoriesAsync()
        {
            var categories = await _categoryRepository.GetAllCategoriesAsync();
            List<CategoryDTO> categoryDTOs = new List<CategoryDTO>();
            foreach (var category in categories)
            {
                categoryDTOs.Add(new CategoryDTO
                {
                    Id = category.Id,
                    Name = category.Name
                });
            }
            return categoryDTOs;
        }

        public async Task<CategoryDTO> GetCategoryByIdAsync(int id)
        {
            var category = await _categoryRepository.GetCategoryByIdAsync(id);
            if (category == null)
                return null;

            return new CategoryDTO { Id = category.Id, Name = category.Name };
        }

        public async Task AddCategoryAsync(CategoryDTO categoryDTO)
        {
            var category = new Category
            {
                Name = categoryDTO.Name,
                CreatedBy = "system",
                UpdatedBy = "system"
            };
            await _categoryRepository.AddCategoryAsync(category);
        }

        public async Task UpdateCategoryAsync(CategoryDTO categoryDTO)
        {
            var existingCategory = await _categoryRepository.GetCategoryByIdAsync(categoryDTO.Id);
            if (existingCategory != null)
            {
                existingCategory.Name = categoryDTO.Name;
                existingCategory.UpdatedBy = "system";
                await _categoryRepository.UpdateCategoryAsync(existingCategory);
            }
        }

        public async Task DeleteCategoryAsync(int id)
        {
            await _categoryRepository.DeleteCategoryAsync(id);
        }
    }

    public class RecipeService : IRecipeService
    {
        private readonly IRecipeRepository _recipeRepository;

        public RecipeService(IRecipeRepository recipeRepository)
        {
            _recipeRepository = recipeRepository;
        }

        public async Task<List<RecipeDTO>> GetAllRecipesAsync()
        {
            var recipes = await _recipeRepository.GetAllRecipesAsync();
            List<RecipeDTO> recipeDTOs = new List<RecipeDTO>();
            foreach (var recipe in recipes)
            {
                recipeDTOs.Add(new RecipeDTO
                {
                    Id = recipe.Id,
                    Name = recipe.Name,
                    CategoryId = recipe.CategoryId,
                    IngredientJson = recipe.IngredientJson,
                    Instructions = recipe.Instructions
                });
            }
            return recipeDTOs;
        }

        public async Task<RecipeDTO> GetRecipeByIdAsync(int id)
        {
            var recipe = await _recipeRepository.GetRecipeByIdAsync(id);
            if (recipe == null)
                return null;

            return new RecipeDTO
            {
                Id = recipe.Id,
                Name = recipe.Name,
                CategoryId = recipe.CategoryId,
                IngredientJson = recipe.IngredientJson,
                Instructions = recipe.Instructions
            };
        }

        public async Task AddRecipeAsync(RecipeDTO recipeDTO)
        {
            var recipe = new Recipe
            {
                Name = recipeDTO.Name,
                CategoryId = recipeDTO.CategoryId,
                IngredientJson = recipeDTO.IngredientJson,
                Instructions = recipeDTO.Instructions,
                CreatedBy = "system",
                UpdatedBy = "system"
            };
            await _recipeRepository.AddRecipeAsync(recipe);
        }

        public async Task UpdateRecipeAsync(RecipeDTO recipeDTO)
        {
            var existingRecipe = await _recipeRepository.GetRecipeByIdAsync(recipeDTO.Id);
            if (existingRecipe != null)
            {
                existingRecipe.Name = recipeDTO.Name;
                existingRecipe.CategoryId = recipeDTO.CategoryId;
                existingRecipe.IngredientJson = recipeDTO.IngredientJson;
                existingRecipe.Instructions = recipeDTO.Instructions;
                existingRecipe.UpdatedBy = "system";
                await _recipeRepository.UpdateRecipeAsync(existingRecipe);
            }
        }

        public async Task DeleteRecipeAsync(int id)
        {
            await _recipeRepository.DeleteRecipeAsync(id);
        }
    }

    public class IngredientService : IIngredientService
    {
        private readonly IIngredientRepository _ingredientRepository;

        public IngredientService(IIngredientRepository ingredientRepository)
        {
            _ingredientRepository = ingredientRepository;
        }

        public async Task<List<IngredientDTO>> GetAllIngredientsAsync()
        {
            var ingredients = await _ingredientRepository.GetAllIngredientsAsync();
            List<IngredientDTO> ingredientDTOs = new List<IngredientDTO>();
            foreach (var ingredient in ingredients)
            {
                ingredientDTOs.Add(new IngredientDTO
                {
                    Id = ingredient.Id,
                    Name = ingredient.Name
                });
            }
            return ingredientDTOs;
        }

        public async Task<IngredientDTO> GetIngredientByIdAsync(int id)
        {
            var ingredient = await _ingredientRepository.GetIngredientByIdAsync(id);
            if (ingredient == null)
                return null;

            return new IngredientDTO { Id = ingredient.Id, Name = ingredient.Name };
        }

        public async Task AddIngredientAsync(IngredientDTO ingredientDTO)
        {
            var ingredient = new Ingredient
            {
                Name = ingredientDTO.Name,
                CreatedBy = "system",
                UpdatedBy = "system"
            };
            await _ingredientRepository.AddIngredientAsync(ingredient);
        }

        public async Task UpdateIngredientAsync(IngredientDTO ingredientDTO)
        {
            var existingIngredient = await _ingredientRepository.GetIngredientByIdAsync(ingredientDTO.Id);
            if (existingIngredient != null)
            {
                existingIngredient.Name = ingredientDTO.Name;
                existingIngredient.UpdatedBy = "system";
                await _ingredientRepository.UpdateIngredientAsync(existingIngredient);
            }
        }

        public async Task DeleteIngredientAsync(int id)
        {
            await _ingredientRepository.DeleteIngredientAsync(id);
        }
    }
}