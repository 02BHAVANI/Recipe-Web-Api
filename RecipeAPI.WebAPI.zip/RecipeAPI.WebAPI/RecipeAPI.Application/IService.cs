﻿using RecipeAPI.Application.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RecipeAPI.Application.Services
{
    public interface ICategoryService
    {
        Task<List<CategoryDTO>> GetAllCategoriesAsync();
        Task<CategoryDTO> GetCategoryByIdAsync(int id);
        Task AddCategoryAsync(CategoryDTO category);
        Task UpdateCategoryAsync(CategoryDTO category);
        Task DeleteCategoryAsync(int id);
    }

    public interface IRecipeService
    {
        Task<List<RecipeDTO>> GetAllRecipesAsync();
        Task<RecipeDTO> GetRecipeByIdAsync(int id);
        Task AddRecipeAsync(RecipeDTO recipe);
        Task UpdateRecipeAsync(RecipeDTO recipe);
        Task DeleteRecipeAsync(int id);
    }

    public interface IIngredientService
    {
        Task<List<IngredientDTO>> GetAllIngredientsAsync();
        Task<IngredientDTO> GetIngredientByIdAsync(int id);
        Task AddIngredientAsync(IngredientDTO ingredient);
        Task UpdateIngredientAsync(IngredientDTO ingredient);
        Task DeleteIngredientAsync(int id);
    }
}